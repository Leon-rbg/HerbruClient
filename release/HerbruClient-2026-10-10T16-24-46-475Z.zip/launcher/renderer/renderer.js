function isSupportedVersion(version) {
    const numericId = /^(\d+)\.(\d+)(?:\.(\d+))?$/.exec(version.id);
    if (numericId) {
        return Number(numericId[1]) > 1 || (Number(numericId[1]) === 1 && Number(numericId[2]) >= 20);
    }
    return Date.parse(version.releaseTime) >= Date.parse('2023-06-07T00:00:00Z');
}
function selectMinecraftVersions(source, type, query) {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    return source.versions.filter((version) => isSupportedVersion(version)
        && (type === 'all' || version.type === type)
        && version.id.toLocaleLowerCase().includes(normalizedQuery));
}
let manifest;
let selectedType = 'all';
const versionList = document.querySelector('#version-list');
const versionSearch = document.querySelector('#version-search');
const catalogCount = document.querySelector('#catalog-count');
const versionSelect = document.querySelector('#home-version');
const supportMatrix = document.querySelector('#support-matrix');
const providerList = document.querySelector('#provider-list');
const modLibraryList = document.querySelector('#mod-library-list');
function getLocalSupportMatrix(manifest) {
    const supported = selectMinecraftVersions(manifest, 'all', '');
    return {
        supportedMinVersion: '1.20.0',
        verifiedBuildTarget: '1.20.1',
        supportedReleaseVersions: supported.filter((version) => version.type === 'release').map((version) => version.id),
        supportedSnapshotVersions: supported.filter((version) => version.type === 'snapshot').map((version) => version.id),
        supportedCount: supported.length,
    };
}
function renderVersion(version) {
    const item = document.createElement('div');
    item.className = 'version-row';
    const identity = document.createElement('div');
    identity.className = 'version-identity';
    const name = document.createElement('strong');
    name.textContent = version.id;
    const badge = document.createElement('span');
    badge.className = `type-badge type-${version.type}`;
    badge.textContent = version.type === 'release' ? 'RELEASE' : version.type === 'snapshot' ? 'SNAPSHOT' : version.type.toUpperCase();
    identity.append(name, badge);
    const date = document.createElement('span');
    date.className = 'version-date';
    const parsedDate = new Date(version.releaseTime);
    date.textContent = Number.isNaN(parsedDate.valueOf()) ? 'Datum nicht verfügbar' : parsedDate.toLocaleDateString('de-DE');
    const state = document.createElement('span');
    state.className = 'version-state';
    state.textContent = 'Im Katalog';
    item.append(identity, date, state);
    return item;
}
function renderVersions() {
    if (!manifest)
        return;
    const versions = selectMinecraftVersions(manifest, selectedType, versionSearch.value);
    versionList.replaceChildren(...versions.map(renderVersion));
    catalogCount.textContent = `${versions.length} Version${versions.length === 1 ? '' : 'en'} angezeigt`;
}
function populateHomeVersions() {
    if (!manifest)
        return;
    const releases = selectMinecraftVersions(manifest, 'release', '');
    const options = releases.map((version) => {
        const option = document.createElement('option');
        option.value = version.id;
        option.textContent = version.id;
        return option;
    });
    versionSelect.replaceChildren(...options);
    if (manifest.latest.release && releases.some((version) => version.id === manifest?.latest.release)) {
        versionSelect.value = manifest.latest.release;
    }
}
function showError(message) {
    versionList.replaceChildren();
    const error = document.createElement('div');
    error.className = 'error-state';
    error.textContent = message;
    versionList.append(error);
    catalogCount.textContent = 'Katalog nicht verfügbar';
    document.querySelector('#connection-status').textContent = 'Offline';
    document.querySelector('.status-dot').classList.add('offline');
}
function renderProviders(providers) {
    providerList.replaceChildren();
    for (const provider of providers) {
        const pill = document.createElement('div');
        pill.className = 'provider-pill';
        const dot = document.createElement('span');
        dot.className = `dot ${provider.status}`;
        const label = document.createElement('span');
        label.textContent = `${provider.name} · ${provider.status}`;
        pill.append(dot, label);
        providerList.append(pill);
    }
}
function renderModLibrary(mods) {
    modLibraryList.replaceChildren();
    if (mods.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.innerHTML = '<span class="empty-mark">◈</span><h2>Keine installierten Mods</h2><p>Die Mod-Bibliothek zeigt die aktuellen installierten Einträge an.</p>';
        modLibraryList.append(empty);
        return;
    }
    for (const mod of mods) {
        const card = document.createElement('div');
        card.className = 'mod-card';
        const info = document.createElement('div');
        const title = document.createElement('h3');
        title.textContent = mod.name;
        const meta = document.createElement('div');
        meta.className = 'mod-meta';
        meta.innerHTML = `<span>${mod.provider}</span><span>v${mod.version}</span><span>${mod.minecraftVersion}</span><span>${mod.loader}</span>`;
        const description = document.createElement('div');
        description.className = 'mod-meta';
        description.textContent = mod.description ?? 'Keine Beschreibung verfügbar.';
        info.append(title, meta, description);
        const status = document.createElement('div');
        status.className = 'mod-status';
        status.textContent = mod.installationStatus;
        card.append(info, status);
        modLibraryList.append(card);
    }
}
document.querySelectorAll('.nav-item').forEach((button) => {
    button.addEventListener('click', () => {
        document.querySelector('.nav-item.active')?.classList.remove('active');
        document.querySelector('.view.active')?.classList.remove('active');
        button.classList.add('active');
        document.querySelector(`#view-${button.dataset.view}`)?.classList.add('active');
        document.querySelector('#breadcrumb-current').textContent = button.textContent?.trim() ?? '';
    });
});
document.querySelectorAll('.filter-button').forEach((button) => {
    button.addEventListener('click', () => {
        document.querySelector('.filter-button.active')?.classList.remove('active');
        button.classList.add('active');
        selectedType = button.dataset.filter;
        renderVersions();
    });
});
versionSearch.addEventListener('input', renderVersions);
void window.herbruClient.getMinecraftVersions().then((result) => {
    manifest = result;
    document.querySelector('#connection-status').textContent = 'Verbunden';
    document.querySelector('#latest-release').textContent = `Aktuelles Release ${result.latest.release}`;
    const matrix = getLocalSupportMatrix(result);
    supportMatrix.textContent = `Unterstützt: ${matrix.supportedMinVersion}+ · Verifiziert: ${matrix.verifiedBuildTarget} · ${matrix.supportedCount} Einträge im Katalog`;
    populateHomeVersions();
    renderVersions();
    return Promise.all([
        window.herbruClient.listModProviders(),
        window.herbruClient.searchMods(''),
    ]);
}).then(([providers, mods]) => {
    renderProviders(providers);
    renderModLibrary(mods);
}).catch((error) => {
    showError(error instanceof Error ? error.message : 'Der Versionskatalog konnte nicht geladen werden.');
    versionSelect.replaceChildren(new Option('Katalog nicht verfügbar', ''));
});
export {};
