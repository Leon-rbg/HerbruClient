package de.herbru.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class HerbruClient implements ClientModInitializer {
    private static boolean hudVisible = true;

    @Override
    public void onInitializeClient() {
        class_304 toggleHud = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.herbruclient.toggle_hud",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "category.herbruclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleHud.method_1436()) {
                hudVisible = !hudVisible;
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (!hudVisible || client.field_1724 == null) {
                return;
            }

            drawContext.method_25303(
                    client.field_1772,
                    "HerbruClient | FPS " + client.method_47599(),
                    8,
                    8,
                    0xEAF5E8
            );
        });
    }
}